#pragma once

#include "math3.h"
#include "MS3D_ASCII.h"


class Vis
{
public:
	math3::Vec3d pos, goalPos;
	Model *model;
public:
	//enum visModel{model1, model2} //this right?:S
	Vis(Model *model); //hihi
	~Vis(void);

	void Update(double dt);
	void Draw();
};
