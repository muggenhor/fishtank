#include "Vis.h"
#include <cstdlib> 
#include <ctime>

float random()
{
	return rand() / float(RAND_MAX);
}

using namespace math3;

const Vec3d aquariumSize(100,100,100);
const double speed=5.0;

Vec3d RandomPos()
{
	Vec3d result;
	result.x=(random()-0.5)*aquariumSize.x;
	result.y=(random()-0.5)*aquariumSize.y; 
	result.z=(random()-0.5)*aquariumSize.z;
	return result;
}

Vis::Vis(Model *model) //defines model
{
	this->model = model;
	pos = RandomPos();
	goalPos = RandomPos();
}

Vis::~Vis(void)
{
}

void Vis::Draw()
{
	if(model)
	{
		glPushMatrix();
		glTranslatef(pos.x,pos.y,pos.z);
		model->render();
		glPopMatrix();
	}
}

void Vis::Update(double dt)
{
	Vec3d delta=goalPos-pos;
	if (Length(delta)<speed*dt)/// if we're about to pass goal in that frame
	{
		goalPos = RandomPos();
	}
	pos += Normalized(delta) * dt * speed;
}